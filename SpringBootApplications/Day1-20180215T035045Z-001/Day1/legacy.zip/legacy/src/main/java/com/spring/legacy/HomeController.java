package com.spring.legacy;

import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spring.legacy.model.Pet;

@RestController
public class HomeController
{
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping("/")
	public Greet sayHello()
	{
		return new Greet("Hello World!");
	}

	@RequestMapping(value = "/entity", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<Pet> entity(HttpEntity<Pet> requestEntity)
	        throws UnsupportedEncodingException
	{
		String requestHeader = requestEntity.getHeaders()
		                                    .getFirst("MyRequestHeader");
		Pet requestBody = requestEntity.getBody();
		// do something with request header and body
		logger.info(requestHeader);
		logger.info(String.valueOf(requestBody));

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set("MyResponseHeader", "MyValue");
		return new ResponseEntity<Pet>(HttpStatus.CREATED);
	}

	@ModelAttribute
	public Pet getPet()
	{
		Pet p = new Pet();
		p.setName("Krishna");
		p.setAge(44);
		return p;
	}
}

class Greet
{
	private String message;

	public Greet(String message)
	{
		this.message = message;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

}
