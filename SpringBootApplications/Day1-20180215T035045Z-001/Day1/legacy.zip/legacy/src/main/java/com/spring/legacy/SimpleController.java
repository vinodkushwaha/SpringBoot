package com.spring.legacy;

import java.io.IOException;
import java.io.Writer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.legacy.model.Pet;

@Controller
public class SimpleController
{

	@RequestMapping("/date")
	public String home(Model model)
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.now();
		String formattedDate = date.format(formatter);

		model.addAttribute("serverDate", formattedDate);
		return "home";
	}

	@RequestMapping(value = "/write-date", method = RequestMethod.PUT)
	public void handle(@RequestBody String body, Writer writer) throws IOException
	{
		writer.write(body);
	}

	@RequestMapping(value = "/pets", method = RequestMethod.POST, consumes = "application/json")
	public @ResponseBody Pet addPet(@RequestBody Pet pet, Model model)
	{
		System.out.println(pet.getName());
		return pet;
	}

}
