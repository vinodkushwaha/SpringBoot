package com.boot.dao;

public class AdminDAO
{
	public void helloAdmin()
	{
		System.out.println("Hello Admin");
	}

}
