package com.boot.dao;

import org.springframework.stereotype.Repository;

@Repository("adminDAO")
public class AdminDAOImpl
{
	public void setupAdmin()
	{
		// default implementation
	}

}
