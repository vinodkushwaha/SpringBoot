package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJournalApplication
{

	public static void main(String[] args)
	{
		SpringApplication.run(SpringBootJournalApplication.class, args);
	}
}
